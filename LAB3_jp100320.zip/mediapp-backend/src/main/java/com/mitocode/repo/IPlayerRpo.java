package com.mitocode.repo;

import com.mitocode.model.Player;

public interface IPlayerRpo extends IGenericRepo<Player, Integer>{
}
