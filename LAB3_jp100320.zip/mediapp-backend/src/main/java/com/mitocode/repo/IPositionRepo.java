package com.mitocode.repo;

import com.mitocode.model.Position;

public interface IPositionRepo extends IGenericRepo<Position, Integer>{
}
