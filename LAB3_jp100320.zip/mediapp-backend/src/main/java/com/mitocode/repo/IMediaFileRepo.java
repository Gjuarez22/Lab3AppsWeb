package com.mitocode.repo;

import com.mitocode.model.MediaFile;

public interface IMediaFileRepo extends IGenericRepo<MediaFile, Integer> {
}
