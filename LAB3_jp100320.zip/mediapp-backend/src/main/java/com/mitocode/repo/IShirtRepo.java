package com.mitocode.repo;

import com.mitocode.model.Shirt;

public interface IShirtRepo extends IGenericRepo<Shirt, Integer>{
}
