package com.mitocode.service;

import com.mitocode.model.Player;

public interface IPlayerService extends ICRUD<Player, Integer>{
}
