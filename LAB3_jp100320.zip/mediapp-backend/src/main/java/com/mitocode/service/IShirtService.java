package com.mitocode.service;

import com.mitocode.model.Shirt;

public interface IShirtService extends ICRUD<Shirt, Integer>{
}
