package com.mitocode.service;

import com.mitocode.model.Position;

public interface IPositionService extends ICRUD<Position, Integer> {
}
